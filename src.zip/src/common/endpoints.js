export const BASE_URL = "https://refuel.site/";
export const BASE_URL_WITHOUTSLASH = "https://revuelive.keycorp.in";
export const PATH = {
  GETLEVEL: BASE_URL + "projects/tutorapp/APIs/LevelList/LevelList.php",
  GETGRADE: BASE_URL + "projects/tutorapp/APIs/GradeList/GradeList.php",
  GETSubject: BASE_URL + "projects/tutorapp/APIs/SubjectList/SubjectList.php",
};
