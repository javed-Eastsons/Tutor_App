import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  Animated,
  Dimensions,
} from "react-native";
import AppIntroSlider from "react-native-app-intro-slider";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { useIsFocused, useNavigation } from "@react-navigation/native";
import { Rating } from "react-native-ratings";
import StarRating from "react-native-star-rating";
import ReadMore from "react-native-read-more-text";
import Swipeable from "react-native-gesture-handler/Swipeable";
const SCREEN_WIDTH = Dimensions.get("window").width;
import { GetAllTutors } from "../Redux/Actions/Tutors";
import { useDispatch, useSelector } from "react-redux";

const ItemBox = (props) => {
  //  console.log("Props.data", props.data);
  const navigation = useNavigation();
  const { Login_Data } = useSelector((state) => state.TutorReducer);

  console.log(Login_Data, "Login_DataLogin_DataLogin_DataLogin_Data");

  const leftSwipe = (progress, dragX) => {
    const scale = dragX.interpolate({
      inputRange: [0, 100],
      outputRange: [0, 1],
    });
    return (
      <TouchableOpacity onPress={props.handleDelete} activeOpacity={0.6}>
        <View style={styles.deleteBox}>
          <Animated.View
            style={{
              transform: [{ scale: scale }],
              backgroundColor: "#fff",
              height: hp(6),
              width: wp(12),
              borderRadius: 50,
              elevation: 7,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Image
              source={require("../Assets/redheart.png")}
              style={{ height: hp(5), width: wp(11) }}
            />
          </Animated.View>
        </View>
      </TouchableOpacity>
    );
  };
  const rightSwipe = (progress, dragX) => {
    const scale = dragX.interpolate({
      inputRange: [0, 100],
      outputRange: [1, 0],
    });
    return (
      <TouchableOpacity onPress={props.handleDelete} activeOpacity={0.6}>
        <View style={styles.deleteBox}>
          <Animated.View
            style={{
              transform: [{ scale: scale }],
              backgroundColor: "#fff",
              height: hp(3),
              width: wp(6),
              borderRadius: 50,
              elevation: 7,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Image
              source={require("../Assets/delete.png")}
              style={{ height: hp(2), width: wp(4) }}
            />
          </Animated.View>
        </View>
      </TouchableOpacity>
    );
  };

  const ratingCompleted = (rating) => {
    console.log("Rating is: " + rating);
  };

  const _renderTruncatedFooter = (handlePress) => {
    return (
      <Text style={{ color: "blue" }} onPress={handlePress}>
        Read more
      </Text>
    );
  };

  const _renderRevealedFooter = (handlePress) => {
    return (
      <Text style={{ color: "blue" }} onPress={handlePress}>
        Show less
      </Text>
    );
  };

  const MOveToNext = () => {
    console.log(Login_Data, "KKK");
    if (Login_Data === "") {
      navigation.navigate("Register");
    } else {
      navigation.navigate("TutorSearchProfile", {
        data: props.data,
      });
    }
  };

  const _handleTextReady = () => {
    // ...
  };
  return (
    <Swipeable renderLeftActions={leftSwipe} renderRightActions={rightSwipe}>
      <View
        style={[
          styles.swipperWrapper,
          {
            backgroundColor: props.index % 2 == 0 ? "#e2e3e9" : "#FFFFFF",
          },
        ]}
      >
        <View style={styles.leftImageWrapper}>
          {props.data.profile_image == null || props.data.profile_image == "" ?
            <Image
              source={require("../Assets/profileImg.png")}
              style={styles.leftImage}
            />
            :
            <Image
              source={{
                uri: `https://colwithfarmchips.co.uk/projects/tutorapp/UPLOAD_file/${props.data.profile_image}`,
              }}
              style={styles.leftImage}
            />
          }
          {/* <Image source={require('../Assets/user.png')} style={styles.leftImage} /> */}

        </View>

        {/* {Tutor && Tutor.map((item) => { */}

        <TouchableOpacity
          onPress={() => MOveToNext()}
          style={styles.widthWrapper}
        >
          {console.log('tutortutortutortutor', `https://refuel.site/projects/tutorapp/flags-medium/${props.flag}.png`)}
          <View>
            <View style={styles.wrraper}>
              <Text style={styles.userIdWrapper}>{props.data.tutor_code}</Text>
              <Image
                source={{ uri: `https://refuel.site/projects/tutorapp/flags-medium/${props.data.flag}.png` }}

                //  source={require("../Assets/flag.png")}
                style={styles.flagImage}
              />
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                height: 20,
                width: "100%",
                marginLeft: 10,
              }}
            >
              <Text
                style={{
                  color: "#000",
                  fontWeight: "500",
                  fontSize: 12,
                  fontFamily: "Poppins-Light",
                }}
              >
                {props.data.qualification}
              </Text>

              <TouchableOpacity
                style={{ height: 40, width: 30, marginRight: wp(4) }}
              >
                <Image
                  source={require("../Assets/Expand.png")}
                  style={{ height: 20, width: 20 }}
                />
              </TouchableOpacity>
            </View>
            <View style={{ width: 80, marginLeft: 5 }}>
              <StarRating
                fullStarColor="orange"
                disabled={false}
                maxStars={5}
                rating={4}
                starSize={15}
              // selectedStar={(rating) => setStrCount(rating)}
              />
            </View>
            <View
              style={{
                height: 20,
                width: "80%",
                marginHorizontal: 10,
                flexDirection: "row",
                position: "absolute",
                left: -70,
                top: 60,
                fontFamily: "Poppins-Light",
              }}
            >
              <Text
                numberOfLines={2}
                style={{
                  color: "black",
                  width: wp(70),
                  fontFamily: "Poppins-Regular",
                  fontStyle: "italic",
                }}
              >
                {props.data.personal_statement}
              </Text>
              <TouchableOpacity>
                <Text
                  style={{
                    color: "#2F5597",
                    fontStyle: "italic",
                    fontFamily: "Poppins-Regular",
                  }}
                >
                  read more
                </Text>
              </TouchableOpacity>
            </View>
            {/* <View style={{height:20,width:"80%",marginLeft:10}}>
                        <Text style={{ color: '#000', fontWeight: '500', fontSize: 12, }}>{props.data.personal_statement}</Text>
                        </View> */}
          </View>
          <View>
            <ReadMore
              numberOfLines={2}
              renderTruncatedFooter={_renderTruncatedFooter()}
              renderRevealedFooter={_renderRevealedFooter()}
              onReady={_handleTextReady()}
            >
              <Text style={{ color: "#000", fontSize: 10 }}>
                {props.data.detail}
              </Text>
            </ReadMore>
          </View>
        </TouchableOpacity>
        {/* })
                } */}
      </View>
    </Swipeable>
  );
};

export default ItemBox;

const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // backgroundColor: '#fff',
    backgroundColor: "pink",
    // padding: 10,
    height: 60,
    width: SCREEN_WIDTH,
    justifyContent: "center",
    padding: 16,
  },
  deleteBox: {
    backgroundColor: "#fff",
    width: 100,
    justifyContent: "center",
    alignItems: "center",
    height: 60,
    top: 20,
  },
  swipperWrapper: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: wp(100),
    marginBottom: hp(1),
    alignSelf: "center",
    // marginLeft: wp(5),
    //  elevation: 5,
    paddingVertical: hp(1),
    borderRadius: 4,
    marginTop: hp(1),
    // backgroundColor:"red"
  },
  leftImageWrapper: {
    width: wp(18),
    alignItems: "center",
    //  justifyContent: "center",
  },
  leftImage: {
    height: 40,
    width: 40,
    borderRadius: 50,
    marginLeft: wp(2),
  },
  widthWrapper: {
    height: 80,
    width: "80%",
  },
  wrraper: {
    flexDirection: "row",
    alignItems: "center",
    height: 20,
    width: "90%",
    marginLeft: 10,
    // marginTop: 10,
  },
  userIdWrapper: {
    color: "#000",
    fontSize: 12,
    fontWeight: "800",
    fontFamily: "Poppins-SemiBold",
  },
  flagImage: {
    height: hp(2),
    width: wp(6),
    marginLeft: wp(2),
  },
});
